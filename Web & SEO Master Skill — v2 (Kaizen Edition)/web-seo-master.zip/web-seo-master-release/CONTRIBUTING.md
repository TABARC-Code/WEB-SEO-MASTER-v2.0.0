# Contributing to web-seo-master

Thanks for your interest in improving this skill. Here's how to contribute.

## Reporting Issues

Found a bug or inaccuracy? Open a GitHub issue with:
- What you were trying to do
- What happened (the problem)
- What you expected to happen
- Which section of the skill (e.g., "google-seo.md — Core Web Vitals section")

## Submitting Improvements

### For Research Updates
If you have newer/better data (2026+), submit a PR with:
- The specific section to update
- The change you're proposing
- Your source (link or citation)
- Why this is an improvement (more accurate, more recent, tested in production)

### For Clarity & Writing
If something is unclear or poorly written:
- Fork the repo
- Edit the file
- Submit a PR with your changes
- Explain what you improved and why

### For New Content
Before adding new sections, open an issue to discuss it. The skill is intentionally comprehensive but focused on web performance, SEO, UX, and conversion — not adjacent topics.

## Code of Conduct

Be respectful. Disagreements are fine; bad faith isn't.

## Questions?

Open an issue or start a discussion. We're here to help.

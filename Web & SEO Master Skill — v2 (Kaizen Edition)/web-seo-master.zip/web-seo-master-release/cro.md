# Conversion Rate Optimisation (CRO) — Deep Reference v2 (2026)

## Table of Contents
1. [CRO Fundamentals](#fundamentals)
2. [The Friction Audit — Worked Process](#friction)
3. [Landing Page Architecture](#landing)
4. [CTA Optimisation — Deep System](#cta)
5. [Trust & Social Proof — Ranked System](#trust)
6. [Forms & Lead Capture](#forms)
7. [Venue / Local Business CRO](#venue)
8. [Page Speed as CRO](#speed)
9. [Psychological Triggers — Ethical Application](#psychology)
10. [A/B Testing Framework](#abtesting)
11. [Email Sequence Templates](#email)
12. [Analytics & Heatmap Workflow](#analytics)
13. [E-commerce CRO](#ecommerce)
14. [SaaS / Lead Gen CRO](#saas)
15. [CRO Benchmarks 2026](#benchmarks)

---

## 1. CRO Fundamentals {#fundamentals}

### CRO vs. UX — The Difference
- **UX**: Does the user understand and enjoy the experience?
- **CRO**: Does the user complete the desired action?
They reinforce each other: better UX → less friction → higher conversion.
But they can conflict: a beautiful journey that doesn't convert is still a failing.

### The CRO Formula
```
Conversion Rate = Goal Completions ÷ Total Visitors × 100

Two levers to pull:
A) Increase goal completions — make converting easier and more compelling
B) Improve visitor quality — better-targeted traffic has higher native intent

Always do A before B.
Fixing a leaky bucket before filling it more is not optional — it's arithmetic.
```

### The Golden Rule of CRO Priority
Fix things in this order:
1. **Trust** — if visitors don't trust you, nothing else works
2. **Clarity** — if they don't understand the offer, nothing else works
3. **Friction** — if converting is hard, reduce effort until it isn't
4. **Motivation** — amplify benefits; reduce perceived risk

---

## 2. The Friction Audit — Worked Process {#friction}

For every conversion path, walk through these 5 questions. Answer honestly.

### The 5 Questions
1. **Motivation**: Is the user's reason to convert strong enough? Does the page amplify it?
2. **Clarity**: Does the user know exactly what they'll get and exactly what to do?
3. **Friction**: What steps, fields, clicks, or decisions make converting harder than it needs to be?
4. **Anxiety**: What fears, doubts, or uncertainties could be stopping them?
5. **Distraction**: What else on the page is competing for their attention at the moment of decision?

### Worked Example (Games Haven)
Conversion goal: table booking via letsbookfor.com

| Question | Finding | Fix |
|---|---|---|
| Motivation | Venue looks fun but value not articulated on homepage | Add "300+ games, £7.50 all day" stat to hero |
| Clarity | No one CTA dominates; two equal CTAs (book + Discord) | Make "Book Table" primary; Discord secondary (outline) |
| Friction | Booking sends user off-site with no trust bridge | Add micro-copy: "Quick 60-second booking — free cancellation" |
| Anxiety | No reviews near book button; no guarantee visible | Add "★ 4.8 from 247 reviews" within 100px of CTA |
| Distraction | Discord CTA competes; pricing buried below fold | Move pricing to hero stats strip; subordinate Discord CTA |

### How to Run a Friction Audit on Any Page
1. Open the page in Incognito mode
2. Pretend you're a first-time visitor who found this from Google
3. Ask: "In 5 seconds, do I know what this is, who it's for, and what to do?"
4. Try to complete the primary conversion with only what's visible
5. Note every moment of hesitation, confusion, or extra click
6. Those moments = friction to remove

---

## 3. Landing Page Architecture {#landing}

### The Conversion-Optimised Page Sequence
```
┌─────────────────────────────────────────────────┐
│  ABOVE THE FOLD — 80% of decisions made here    │
│                                                 │
│  H1: Primary keyword + clear benefit            │
│  Sub-headline: removes biggest objection        │
│  Hero visual: reinforces benefit; real people   │
│  PRIMARY CTA: benefit label; high contrast      │
│  Micro-copy: removes anxiety                    │
│  Trust strip: ★★★★★ 4.8 from 247 reviews       │
└─────────────────────────────────────────────────┘

│  PROBLEM SECTION — agitate the pain            │
│  "Tired of playing the same 3 games at home?"  │

│  SOLUTION SECTION — position as answer         │
│  "Games Haven has 300+ games, expert guides,   │
│   and a community ready to play"               │

│  FEATURES → BENEFITS                           │
│  Feature tells; benefit sells                  │
│  "300 games" → "Never play the same game twice"│

│  SOCIAL PROOF                                  │
│  Real testimonials with outcomes               │

│  OBJECTION HANDLING (FAQ)                      │
│  Answer the 5 reasons they don't convert       │

│  RISK REVERSAL                                 │
│  Guarantee / free cancellation / refund        │

│  FINAL CTA                                     │
│  Repeat primary CTA; different visual variant  │
└─────────────────────────────────────────────────┘
```

### Message Match Principle
Every landing page must immediately match the ad, email, or search result that brought the visitor.
- Ad says "Free board game taster session" → page headline says exactly that
- Email says "Book your spot for Saturday gaming night" → page is about Saturday night booking
- Mismatch = visitor feels they landed in the wrong place = immediate bounce

### Headline Formulas
| Formula | Example |
|---|---|
| [Outcome] for [Audience] | "Unforgettable Game Nights for Nottingham Families" |
| [Result] Without [Fear] | "Play 300+ Board Games Without Buying a Single One" |
| [Timeframe] to [Outcome] | "Book Your Table in 60 Seconds" |
| The [Adjective] Way to [Outcome] | "The Easiest Way to Meet Nottingham Gamers" |
| [Number] + [Outcome] | "300+ Games. One Price. All Day." |
| How [Person] [Result] | "How Nottingham's Gaming Community Found Its Home" |

---

## 4. CTA Optimisation — Deep System {#cta}

### The Six CTA Rules
1. **One primary per section** — multiple competing CTAs split attention; both perform worse
2. **Benefit-focused label** — what the user gets, not what they do
3. **Visual contrast** — must stand out from everything on the page; accent colour used nowhere else
4. **Appropriate size** — large enough to command attention; not so large it looks desperate
5. **Breathing space** — surround with whitespace; crowded CTAs are overlooked
6. **Repetition** — above fold + after every major value section + footer

### CTA Copy Ladder (Best to Worst)
| Tier | Formula | Example |
|---|---|---|
| Best | First-person outcome | "Reserve My Table" / "Start Growing My Channel" |
| Good | Second-person benefit | "Book Your Gaming Session" / "Grow Your Channel" |
| Acceptable | Action + object | "Book a Table" / "Start Free Trial" |
| Poor | Generic action | "Click Here" / "Go" / "Continue" |
| Worst | System language | "Submit" / "Send" / "Process" |

### CTA Code — Full Implementation
```css
.btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--accent);
  color: var(--text-on-accent);
  font-size: clamp(1rem, 1.5vw, 1.125rem);
  font-weight: 600;
  padding: 14px 32px;
  border-radius: 6px;
  border: 2px solid transparent;
  cursor: pointer;
  text-decoration: none;
  white-space: nowrap;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}
.btn-primary:active { transform: translateY(0); box-shadow: none; }
.btn-primary:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }

.btn-secondary {
  /* Same text; outline variant — clearly subordinate */
  background: transparent;
  color: var(--accent);
  border: 2px solid var(--accent);
}
.btn-secondary:hover { background: var(--accent-light); }
```

### Micro-Copy Under CTA (Removes Last Objection)
Always add 1 line of micro-copy directly under the primary CTA:
- "Free cancellation up to 24 hours before your session"
- "Takes 60 seconds to book"
- "No account needed"
- "No credit card required"
- "Cancel anytime — no questions asked"

---

## 5. Trust & Social Proof — Ranked System {#trust}

### Six Types of Social Proof (Most to Least Persuasive)
1. **Case studies** — specific, quantified, real outcomes ("increased sales 340% in 3 months")
2. **Video testimonials** — video adds humanity and authenticity text can't replicate
3. **Named photo testimonials** — real name + real photo + role/company/location
4. **Star ratings + count** — aggregate proof ("4.8★ from 247 reviews")
5. **Client/press logos** — authority by association
6. **Usage numbers** — "Visited by 15,000+ players in 2025"

### Trust Signal Placement Rules
| Location | What to Place |
|---|---|
| Above fold (hero strip) | Star rating + review count OR usage number |
| Within 100px of primary CTA | 1–2 testimonials OR guarantee statement |
| Near pricing | Testimonials mentioning value or ROI |
| Objection-handling section | Testimonials that answer specific doubts |
| Footer | Trust badges, certifications, payment icons |

### Testimonial Best Practices
- Specific outcome > vague positive feeling
  - "My traffic went from 2K to 18K monthly visits in 4 months" > "Really helpful, would recommend"
- Always include: full name + photo + role or location (anonymous = low credibility)
- Outcome-focused: what changed for them? What result did they achieve?
- Match testimonial type to the objection it overcomes

### Risk Reversal Options (Highest to Lowest Impact)
1. Free trial — removes all financial risk
2. Money-back guarantee with specific terms ("30-day no-questions refund")
3. Free cancellation policy (ideal for venue bookings)
4. Free consultation / demo / taster session
5. Satisfaction guarantee ("If you're not happy, we'll make it right")

---

## 6. Forms & Lead Capture {#forms}

### The Field Count Rule
Every additional field reduces form completion by 10–15%.
Minimum viable fields only. Ask only what you need at this stage.

| Form Type | Fields |
|---|---|
| Email opt-in | Email only (or First name + email) |
| Event booking | Name + email + date/time |
| Contact form | Name + email + message |
| Lead gen (B2B) | Name + email + company + one qualifying question |
| Full purchase | Standard shipping/payment — no extras |

### Multi-Step Form Pattern
For unavoidably long forms, break into steps:
- Step 1: Easy/non-threatening (name, email)
- Step 2: More specific (preferences, details)
- Step 3: Commitment (payment, phone)
Show a clear progress bar. Users who complete step 1 are psychologically committed to finishing.

### Form UX Requirements
- [ ] Labels above fields (not placeholder-only — disappears on focus)
- [ ] Correct `type`: `email`, `tel`, `number`, `date`, `text`
- [ ] `autocomplete` attributes: `given-name`, `email`, `tel`, `street-address`
- [ ] Inline validation: ✓ icon when field correctly filled; error adjacent to field
- [ ] Error messages: "Enter a valid email (e.g. name@example.com)" not "Invalid input"
- [ ] Submit button: outcome label not "Submit"
- [ ] Mobile: inputs trigger correct keyboard; no auto-zoom on font < 16px

### Email Capture Value Exchange
| Weak (< 0.5% opt-in) | Strong (2–6% opt-in) |
|---|---|
| "Subscribe to our newsletter" | "Get our free Beginner's Guide to Board Games" |
| "Join our mailing list" | "Get member-only early access to new events" |
| "Stay updated" | "Get the free Nottingham Gamer's Calendar every month" |
| "Sign up for news" | "Get 10% off your first membership with our welcome offer" |

### Thank-You Page Optimisation
Don't waste the thank-you page — it's peak engagement moment:
- Confirm what they'll receive and when
- Offer next step: related content, social channels, a product
- Add social sharing: "Tell a friend who'd love this"
- Re-state the value: "You've joined 3,400 Nottingham gamers"

---

## 7. Venue / Local Business CRO {#venue}

This section is dedicated to physical venues, cafés, and local service businesses.
The conversion path is different: visitor → booking/footfall, not checkout.

### The Venue Conversion Path
```
Search result → Landing page → Understand the offer → Trust the venue → Book / visit
```
Every break in this chain loses a potential visitor.

### Above-Fold Requirements for a Venue
1. Venue name + clear description (what kind of place is this?)
2. Location (city/area, not just postcode)
3. Opening hours prominently visible
4. Pricing visible (£7.50pp) — decision-critical; don't hide it
5. Booking CTA — one clear button
6. Real photo of the venue interior (atmosphere = intent)
7. Social proof: Google review rating + count

### Booking CTA Best Practices for Venues
- CTA label: "Book My Table" / "Reserve a Spot" / "Check Availability"
- Never: "Click Here" / "Book Now" (vague)
- If booking is off-site (third party): add micro-copy bridge
  "Quick 60-second booking on our reservations partner"
- Show: "Free cancellation up to 24h before" if applicable
- Show: next available slot if possible ("Tables available this Thursday from 5pm")

### Venue-Specific Trust Signals
- Google rating + count (4.8★ from 247 reviews) — most powerful for local venues
- DBS check badge (especially for venues with families/children — Games Haven has this)
- Accessibility statements: wheelchair accessible, LGBTQ+ welcoming, neurodivergent-friendly
- Press coverage: local newspaper features, community recognition
- Event photos: real atmosphere; real people having real fun

### Opening Hours — CRO Implications
Opening hours are the most commonly searched fact for a local venue.
- On homepage above fold (not buried in footer)
- In Google Business Profile (kept up to date; holiday hours updated in advance)
- In LocalBusiness schema
- On the Contact page
- Consistent across all four locations — any mismatch creates doubt

### Membership as CRO Tool
For venues with membership tiers:
- Surface membership near the session pricing
- Frame as: "Regular visitor? Membership pays for itself after [X] visits"
- Show the per-visit saving: "Members pay £5.50pp instead of £7.50"
- Add a dedicated membership page accessible from the primary nav

---

## 8. Page Speed as CRO {#speed}

Speed is not an SEO-only metric — it directly kills conversions:
- 1-second delay → 7% conversion drop (Amazon data)
- 53% mobile users abandon after 3 seconds (Google data)
- Load time improvement from 6s → 2s can more than double conversion rate

### Speed → Conversion Impact
| Load Time | Conversion Impact |
|---|---|
| < 1 second | Near-maximum potential |
| 1–2 seconds | Excellent; minimal drop |
| 2–3 seconds | Acceptable; ~10–15% below optimum |
| 3–5 seconds | Significant drop; 30–50% below optimal |
| > 5 seconds | Severe; fix speed before any other CRO work |

### Speed Quick Wins (in priority order)
1. Upgrade hosting if TTFB > 800ms (hosting is the foundation; CDN doesn't fix a slow origin)
2. Add Cloudflare (free tier) — CDN + caching + DDoS protection immediately
3. Compress hero image to < 200KB as WebP
4. Add explicit `width` + `height` to all images (prevents CLS = perceived speed)
5. Defer booking widget, chat, analytics JS (`defer` attribute)
6. Preload the LCP hero image (`<link rel="preload" as="image">`)
7. Inline critical CSS (above-fold styles) in `<style>` tag; load rest async

---

## 9. Psychological Triggers — Ethical Application {#psychology}

Apply all triggers honestly — they work because they reflect real human decision-making.
Fake scarcity or manufactured urgency permanently destroys trust when discovered.

### Scarcity & Urgency
- Real deadline timers: "Tournament registration closes Friday" — only when true
- Limited availability: "Only 6 table spots left this Saturday" — only when accurate
- Seasonal urgency: "Our Christmas gaming nights are selling out" — only when true
- Never: fake countdown timers that reset; "Only 3 left" when there are 300

### Loss Aversion (2× stronger than equivalent gain)
- Frame as loss: "Don't miss out on the only RPG night this week"
- Guarantee framing: "You risk nothing — free cancellation any time"
- Opportunity cost: "Every week you wait is another week without a gaming community"

### Social Proof / Bandwagon
- "Join 3,400 Nottingham gamers who've already played with us"
- "Most popular session: Thursday Board Game Social"
- "Visited by 15,000+ players in 2025"

### Authority
- Press coverage: "As featured in Nottingham Post"
- Certifications: DBS check, accessibility accreditation
- Expert endorsement: game designer, local gaming club leader

### Reciprocity
- Give genuinely useful free content (games guide, beginner's guide, event calendar)
- Free taster session or first-visit discount
- Free download creates obligation to reciprocate

### Commitment & Consistency
- Small commitment leads to larger commitment
- RSVP to a free event → attend → become a member
- Join Discord → engage → book a table → become regular

### Anchoring
- Show full membership value before monthly price ("That's over £200 of free gaming for £19/month")
- Show full day pricing then the per-hour breakdown ("£7.50 for up to 8 hours of gaming")

---

## 10. A/B Testing Framework {#abtesting}

### Testing Priority (highest expected ROI first)
1. Headline / H1 — highest impact single element on any page
2. Primary CTA — label, colour, size, placement
3. Hero image/video — what visual reinforces value best?
4. Social proof placement — above fold vs. below features
5. Pricing presentation — order, emphasis, framing
6. Form field count — remove one field at a time; measure completion rate

### A/B Testing Rules
- Test one variable per experiment
- Statistical significance: 95% confidence minimum
- Minimum duration: 2 weeks (captures weekly behavioural cycles)
- Minimum sample: ~1,000 visitors per variant for most tests
- Never stop early based on early results (regression to the mean is real)
- Segment results: mobile vs. desktop often behave very differently

### What to Measure
- Primary: conversion rate for the specific goal being tested
- Secondary: bounce rate, time on page, scroll depth (understand *why* a variant won)
- Always watch for: device-type differences; traffic source differences

### Recommended Tools (2026)
| Tool | Best For | Cost |
|---|---|---|
| VWO | Full-stack A/B + heatmaps | Paid |
| Optimizely | Enterprise; complex experiments | Paid |
| Convert.com | Mid-market; clean interface | Paid |
| GrowthBook | Developer-friendly; open source | Free/paid |
| Statsig | Product teams; feature flags + experiments | Free/paid |
| YouTube Studio | Thumbnail + title A/B (eligible channels) | Free |
| Mailchimp/Klaviyo | Email subject line + send-time testing | In-platform |

---

## 11. Email Sequence Templates {#email}

### Welcome Sequence (5-email, 10-day)
```
Day 0 (immediate): Deliver the promised resource + one clear next step
Day 1: Value email — your most useful free content (no ask)
Day 3: Story email — founder/team story; why this exists; human connection
Day 5: Social proof email — specific customer outcome or case study
Day 7: Soft offer — membership / booking / product with specific benefit
Day 10: Last-chance variant — "You still haven't [taken the action]" + specific urgency
```

### Abandoned Booking Sequence (for venues)
```
1 hour after: "Did something come up? Your booking is still available"
              → Link back to the booking page; no pressure
24 hours:     Social proof email — "Here's what happened at our last event..."
              → Photos, testimonials, what they missed
72 hours:     Offer — "We'd love to have you: [specific incentive]"
              → Discount or free upgrade; only if available
```

### Post-Visit Re-engagement Sequence
```
24h after visit: "Thanks for coming — how was it?" → Review request link
1 week later:   "You might have missed this event coming up this week" → Event CTA
3 weeks later:  Membership offer — "Regular visitor? Here's what membership saves you"
6 weeks later:  "Haven't seen you in a while — here's what's new at Games Haven"
```

---

## 12. Analytics & Heatmap Workflow {#analytics}

### GA4 Event Setup for Venue / Local Business
```javascript
// CTA click
document.querySelector('.btn-primary').addEventListener('click', () => {
  gtag('event', 'cta_click', { cta_label: 'book_table', location: 'hero' });
});

// Booking initiated (external link)
document.querySelector('[href*="letsbookfor.com"]').addEventListener('click', () => {
  gtag('event', 'begin_checkout', { method: 'letsbookfor' });
});

// Phone number click (mobile)
document.querySelector('a[href^="tel:"]').addEventListener('click', () => {
  gtag('event', 'call_click', { phone_location: 'footer' });
});

// Scroll milestones
const observer = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting) {
    gtag('event', 'scroll_depth', { depth: '50_percent' });
    observer.disconnect();
  }
});
observer.observe(document.querySelector('#halfway-marker'));
```

### Heatmap Analysis Workflow
Monthly:
1. Check click maps: are users clicking non-clickable elements? (add links there)
2. Check scroll maps: where do most users stop? (if above your CTA, move CTA up)
3. Watch 5 session recordings of people who bounced without converting
4. Watch 5 session recordings of people who converted
5. Identify: what did converters do differently? Remove the friction that stopped the others

### Form Analytics Workflow
For every important form:
- Which field has the highest abandonment rate? → Simplify or remove it
- What's the time-per-field for the longest field? → Users spending > 30s on one field = friction
- At what point do users restart the form? → That field is confusing

---

## 13. E-commerce CRO {#ecommerce}

### Product Page Checklist
- [ ] Multiple images (360°, lifestyle, in-context, close-up detail)
- [ ] Video demo for complex/non-obvious products
- [ ] Price prominently displayed (hidden price = maximum anxiety)
- [ ] Stock indicator when low: "Only 4 left" (real scarcity only)
- [ ] Delivery date shown (not just "3–5 business days") — #1 abandonment cause
- [ ] Reviews directly below product name (before the fold)
- [ ] Sticky Add to Cart button on mobile
- [ ] Related products below "Add to Cart" (increases average order value)

### Checkout Optimisation
- [ ] Guest checkout option (no mandatory account)
- [ ] Progress bar: "Step 2 of 3"
- [ ] Order summary visible throughout checkout
- [ ] Multiple payment methods: card, PayPal, Apple/Google Pay, BNPL
- [ ] `autocomplete` on every form field
- [ ] Trust badges near payment input (Secure checkout, SSL, payment logos)
- [ ] No surprise fees (show shipping cost before final step)

### Cart Abandonment Sequence
```
1 hour:   Reminder — "You left something behind" + cart contents + Continue
24 hours: Proof email — review of the product they almost bought
72 hours: Incentive — [discount/free shipping] if available
```

---

## 14. SaaS / Lead Gen CRO {#saas}

### Free Trial Optimisation
- "No credit card required" — single biggest conversion lift; mention in headline + CTA + micro-copy
- Reduce time-to-value: user must experience core value within 5 minutes of signing up
- Onboarding email: trigger on activation events, not just time elapsed
- In-app prompts toward the "aha moment" (first successful outcome)

### Pricing Page Best Practices
- 3 plans (choice paradox: more = lower conversion)
- Highlight recommended plan ("Most Popular" badge with border accent)
- Annual/monthly toggle with saving prominently shown ("Save 20% annually")
- Features table: lead with user benefits, not technical specs
- CTA on every plan (not one page CTA)
- FAQ section on pricing page: address cost/value/cancellation objections
- Enterprise row: "Custom pricing for teams over 50 — Contact us"

### B2B Lead Gen Form
- Progressive profiling: basic info first; detailed qualifying questions later
- Context for every field: explain why you need it
- Instant automated response with specific next steps
- Qualifying question at the end: "What's your primary challenge?" (improves sales efficiency)
- Multiple commitment levels: "Book a call" AND "Download the guide" (different readiness)

---

## 15. CRO Benchmarks 2026 {#benchmarks}

Use these as directional targets — your baseline is your baseline. Improvement % matters more.

### Conversion Rates
| Context | Average | Strong |
|---|---|---|
| E-commerce (retail) | 2.5–3% | > 4% |
| SaaS free trial | 3–5% | > 8% |
| Lead generation form | 5–8% | > 12% |
| B2B contact form | 2–4% | > 6% |
| Venue/event booking | 3–6% | > 10% |
| Email opt-in (pop-up, value exchange) | 2–4% | > 6% |
| Email opt-in (embedded, no incentive) | 0.3–0.8% | > 2% |
| Email opt-in (embedded, value exchange) | 1–3% | > 5% |

### Email Performance
| Metric | Average | Strong |
|---|---|---|
| Welcome email open rate | 50–60% | > 70% |
| Standard list open rate | 20–30% | > 40% |
| Click-through rate | 2–5% | > 8% |
| Unsubscribe rate (per send) | < 0.5% | < 0.2% |

### YouTube CTA (End Screen / Card)
| CTA Type | Average CTR |
|---|---|
| End screen to video | 0.5–2% |
| End screen to subscribe | 0.3–1% |
| Info card to related video | 0.2–0.8% |
| Description link click | 0.1–0.5% |

All benchmarks: niche, audience, and page quality vary significantly. Use as starting orientation only.

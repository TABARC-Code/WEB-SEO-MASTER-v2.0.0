# Google SEO — Deep Reference v2 (2026)

## Table of Contents
1. [Search Intent Framework](#intent)
2. [E-E-A-T — Implementation Guide](#eeat)
3. [Keyword Research — Full Process](#keywords)
4. [On-Page SEO Checklist](#onpage)
5. [Technical SEO Checklist](#technical)
6. [Core Web Vitals — Deep Dive](#cwv)
7. [Content Strategy & Freshness](#content)
8. [Featured Snippets & Rich Results](#snippets)
9. [Link Building — 2026](#links)
10. [AI Search Optimisation (GEO/AIO)](#ai)
11. [Local SEO — Deep Dive](#local)
12. [Keyword Cannibalism Diagnosis](#cannibalism)
13. [Penalty & Traffic Drop Recovery](#recovery)
14. [Schema Reference — Full Templates](#schema)

---

## 1. Search Intent Framework {#intent}

Intent is the first gate. Wrong intent = irrelevant page regardless of quality.

### The Four Types
| Type | User Goal | Expected Format |
|---|---|---|
| Informational | Learn something | Blog post, guide, how-to, video |
| Navigational | Find a specific brand/site | Homepage, brand landing page |
| Commercial | Research before buying | Comparison, review, "best X" listicle |
| Transactional | Buy, book, sign up now | Product/service page, pricing, booking |

### How to Identify Intent (3-Step Process)
1. Search the keyword in Incognito mode
2. Examine top 5 results: **format** (listicle? how-to? product page?), **angle** (beginner? expert? local?), **depth** (word count, sections, media)
3. Match all three — a page that matches intent on format but not angle will still struggle

### Real-World Examples
- "board game café nottingham" → Transactional: they want to visit; page needs opening hours, booking CTA, address
- "best board games for couples" → Commercial: comparing options; needs listicle with verdict per game
- "how to run a d&d one-shot" → Informational: learning; needs step-by-step guide with examples
- "games haven" → Navigational: looking for the brand; homepage should rank

### Intent Mismatch Diagnosis
| Symptom | Cause | Fix |
|---|---|---|
| High impressions, low CTR | Title signals wrong intent | Rewrite title to match intent + curiosity |
| High CTR, high immediate bounce | Page doesn't match what title promised | Align content with intent; restructure hero |
| Rankings fall over time | Intent of query drifted; top results evolved | Refresh content format and angle |

---

## 2. E-E-A-T — Implementation Guide {#eeat}

Experience, Expertise, Authoritativeness, Trustworthiness. Google's quality evaluator framework.

### Experience (most underimplemented)
- First-person proof: "I tested this over 6 months", original photos, personal case data
- "We tested 15 two-player games with real couples" > "Here are 15 games for couples"
- "Updated [specific date]" stamps — with genuinely refreshed content, not cosmetic date bumps
- Original research, real numbers, real outcomes from real use

### Expertise
- Author bio with verifiable credentials, links to other published work
- Cite authoritative sources — link out to .gov, .edu, peer-reviewed, recognised industry bodies
- Depth: answer follow-up questions the reader will have before they have them
- Writing structured as an expert would, not as keyword filler

### Authoritativeness
- Backlinks from topically relevant, high-authority sites (niche relevance > generic DA)
- Brand mentions without links still signal authority (brand entity signals)
- Consistent publishing within one niche builds topical authority faster than scattered topics

### Trustworthiness (often the blocking factor for local/YMYL)
- HTTPS everywhere (mandatory)
- Clear About page with real names, founding story, credentials
- Privacy policy, terms, contact info with phone and address
- No misleading headlines; content delivers exactly what title promises
- Visible review count or verification badges near primary CTA

### E-E-A-T Audit Checklist
- [ ] Author name visible on every article with bio link
- [ ] About page exists with real team info and venue/company story
- [ ] First-person language or direct experience signals in content body
- [ ] External links to authoritative sources (2–4 per content page)
- [ ] Reviews or ratings visible on key pages
- [ ] Contact details (phone + address) in footer of every page
- [ ] Privacy policy and terms linked in footer

---

## 3. Keyword Research — Full Process {#keywords}

### Step 1: Intent-First Seeds
Start by mapping the user journeys for your audience, not by searching for keywords:
- What do they search when they want to visit? (transactional)
- What do they search when deciding? (commercial)
- What do they search to learn? (informational)
- What do they search to find you specifically? (navigational)

Each category needs its own pages — you cannot serve all intents on one URL.

### Step 2: Expand with Tools
| Tool | Best For |
|---|---|
| Google Autocomplete + "People Also Ask" | Real user phrasing; zero-cost |
| Google Search Console | Keywords you already rank for (pages 2–5 = opportunity) |
| Google Keyword Planner | Volume + CPC (high CPC = commercial intent) |
| Ahrefs / Semrush | Keyword difficulty, SERP analysis, competitor gaps |
| Answer the Public / AlsoAsked | Question-format keywords for FAQs and featured snippets |
| Google Trends | Seasonal/trending signals; validate keyword before investing |

### Step 3: Evaluate Each Keyword
| Factor | What Good Looks Like |
|---|---|
| Search volume | Monthly average >100; zero-volume traps are real |
| Keyword difficulty (KD) | New domain: <30; established: 30–70; authority site: 70+ |
| Intent clarity | One obvious intent type = easier to optimise |
| Business fit | Does ranking here bring buyers/visitors, not random traffic? |
| SERP features | Video carousel? Featured snippet? = extra opportunity |
| Competition quality | Can you create something meaningfully better than top 5? |
| Seasonal pattern | Avoid declining trends; favour growing or stable |

### Step 4: Keyword Mapping (One URL = One Primary Intent)
- One primary keyword per URL
- 3–8 semantic/secondary keywords naturally embedded
- Cluster related keywords: one pillar page + supporting cluster pages
- Never target the same intent from two different URLs (see Cannibalism section)

### Long-Tail Strategy
Long-tail = more specific, lower competition, higher conversion intent.
Build from long-tail first → establish authority → expand to head terms.
Example:
- Start: "board game café for families nottingham" (long-tail, local, high intent)
- Build to: "board game café nottingham" (mid-tail)
- Eventually: "board game café uk" (head term)

---

## 4. On-Page SEO Checklist {#onpage}

### URL
- [ ] Short, descriptive, lowercase, hyphen-separated
- [ ] Primary keyword in slug
- [ ] No dates (creates staleness perception and complicates refreshes)
- [ ] Max 2 directory levels deep: `/category/page-name/` not `/a/b/c/d/page/`
- [ ] Permanent — changing URLs loses link equity unless 301-redirected immediately

### Title Tag
- [ ] Primary keyword in first 3 words
- [ ] ≤60 characters (~580px) — Google rewrites longer titles
- [ ] Unique to this page (duplicate titles = Google picks one to rank)
- [ ] Brand name at end: `Primary Keyword — Benefit | Brand`
- [ ] Includes a differentiator or power word where space allows

### Meta Description
- [ ] ≤155 characters
- [ ] Primary keyword included naturally (Google bolds it in SERPs)
- [ ] Clear benefit hook: what will the user gain by clicking?
- [ ] Ends with implied or explicit CTA: "Find out how", "Book your table"
- [ ] Not duplicated across pages

### Heading Structure
- [ ] One H1 per page — primary keyword + value proposition
- [ ] H2s cover main topic facets — use semantic keyword variants
- [ ] H3s for subsections — question format works well for featured snippets
- [ ] No heading level skipping (H1 → H2 → H3, not H1 → H3)
- [ ] No keyword stuffing in headings — natural language first

### Content Body
- [ ] Primary keyword in first 100 words (naturally)
- [ ] Answers the core query directly at the top, then expands
- [ ] Semantic keywords woven throughout — not listed, not stuffed
- [ ] Original data, first-person examples, or expert quotes included
- [ ] Internal links: 3–8 contextual links to related pages
- [ ] External links: 2–4 to authoritative sources (rel="noopener" + target="_blank")
- [ ] Content length matches top 5 competitor pages (benchmark, don't pad)
- [ ] "Last updated" date visible and accurate (not cosmetic)
- [ ] Reading time indicator on long-form content

### Images
- [ ] Alt text: descriptive, keyword-relevant, not stuffed
- [ ] Filename: `descriptive-keyword-phrase.webp` not `IMG_1234.jpg`
- [ ] Explicit `width` and `height` attributes on every image (CLS prevention)
- [ ] Format: WebP or AVIF (AVIF preferred for quality-to-size ratio)
- [ ] Hero image: < 200KB; body images: < 100KB
- [ ] Below-fold images: `loading="lazy"`
- [ ] Hero/LCP image: `fetchpriority="high"` + `<link rel="preload">`

### Schema Markup
- [ ] Correct type for page (LocalBusiness, Article, FAQPage, HowTo, VideoObject...)
- [ ] All required fields populated (no empty strings)
- [ ] Validated with Google Rich Results Test (zero errors, zero warnings)
- [ ] FAQPage added to any page with FAQ section (drives accordion rich result)

---

## 5. Technical SEO Checklist {#technical}

### Crawlability & Indexing
- [ ] `robots.txt` blocks staging/admin; allows all important pages
- [ ] XML sitemap generated and submitted to GSC
- [ ] No accidental `noindex` on important pages (check GSC Coverage tab)
- [ ] Canonical tags on every page (self-referencing at minimum)
- [ ] Pagination: use `rel="next"` / `rel="prev"` or paginate via URL parameters with canonicals
- [ ] Redirect chains ≤ 1 hop (A→B→C should be A→C immediately)
- [ ] Only 301 redirects for permanent moves (302 passes no equity)
- [ ] No broken links (404s) — crawl monthly; check GSC

### Site Architecture
- [ ] All important pages within 3 clicks from homepage
- [ ] Flat structure preferred: avoid /category/subcategory/sub-subcategory/ depth
- [ ] Breadcrumbs on all inner pages (UX + Google understands hierarchy)
- [ ] Internal link equity flows from high-DA pages to target pages (strategic internal linking)
- [ ] Footer links: only to genuinely important pages (diluting footer = diluting equity)

### HTTPS & Security
- [ ] HTTPS everywhere; HTTP redirects to HTTPS via 301
- [ ] No mixed content warnings (HTTP assets on HTTPS page)
- [ ] HSTS header set (`Strict-Transport-Security: max-age=31536000`)
- [ ] No malware or security flags in GSC

### Mobile
- [ ] Responsive design (single URL, not m. subdomain)
- [ ] Viewport meta tag: `<meta name="viewport" content="width=device-width, initial-scale=1">`
- [ ] No Flash, no non-mobile-friendly plugins
- [ ] Font sizes readable without zooming (≥16px body)
- [ ] Touch targets ≥ 44×44px

### Page Speed (Technical)
- [ ] TTFB < 800ms (hosting/CDN quality gate)
- [ ] Render-blocking JS deferred or async
- [ ] Critical CSS inlined; non-critical CSS loaded async
- [ ] Web fonts: `font-display: optional` or preloaded
- [ ] Unnecessary plugins removed (WordPress: each plugin = JS + CSS overhead)
- [ ] Caching headers set: `Cache-Control: max-age=31536000` for static assets

### Common WordPress-Specific Issues
- Auto-publishing third-party plugins (e.g. Social Media Auto Publish by XYZScripts) add bloat JS — remove
- BookingNinja / LetsbookFor widgets: defer their JS; load async; don't let them block render
- Multiple page builders (Elementor + Gutenberg + Divi) stack CSS — use only one
- Image compression plugin required: ShortPixel or Imagify (auto-convert to WebP on upload)

---

## 6. Core Web Vitals — Deep Dive {#cwv}

**Key principle**: Google uses CrUX field data (real Chrome users), not lab scores alone.
Pass = 75% of page visits score "Good" on all three metrics simultaneously.

### Largest Contentful Paint (LCP) — Load Performance
**Good**: < 2.5s | **Needs Improvement**: 2.5–4.0s | **Poor**: > 4.0s

What it measures: when the largest visible element finishes loading (usually hero image or H1 text block).

**Fixes in priority order:**
1. **Upgrade hosting / add CDN** — TTFB > 800ms = hosting problem; fix this first
2. **Preload the LCP image** — `<link rel="preload" as="image" href="hero.webp" fetchpriority="high">`
3. **Convert to WebP/AVIF** — AVIF typically 50% smaller than JPEG at equivalent quality
4. **Compress hero image** — target < 200KB; use Squoosh or ShortPixel
5. **Eliminate render-blocking resources** — defer JS; inline critical CSS
6. **Use `fetchpriority="high"`** on the LCP image element itself

### Interaction to Next Paint (INP) — Responsiveness
**Good**: < 200ms | **Needs Improvement**: 200–500ms | **Poor**: > 500ms

What it measures: latency of ALL interactions during the session (replaced FID March 2024).

**Fixes in priority order:**
1. **Defer third-party scripts** — analytics, chat widgets, tag managers, social embeds load after paint
2. **Break up long JavaScript tasks** (> 50ms) using `scheduler.yield()` or `setTimeout(fn, 0)`
3. **Minimise DOM size** — < 1,500 nodes; deep DOMs slow interaction response
4. **Debounce scroll/resize handlers** — `window.addEventListener('scroll', fn, { passive: true })`
5. **Web workers for CPU-heavy operations** — parsing, sorting, encryption off the main thread

### Cumulative Layout Shift (CLS) — Visual Stability
**Good**: < 0.1 | **Needs Improvement**: 0.1–0.25 | **Poor**: > 0.25

What it measures: unexpected layout movements during and after page load.

**Fixes in priority order:**
1. **Always set width + height on every image and video** — single most common cause
2. **Reserve space for embeds** — `aspect-ratio: 16/9` container for iframes/videos
3. **Don't inject content above existing content** after load (banners, cookie bars, consent dialogs)
4. **Preload web fonts** — `font-display: optional` prevents FOUT; or preload font files
5. **Animate only transform + opacity** — never animate width/height/margin/padding/top/left

### Diagnosing CWV Without GSC Access
When you can only inspect source HTML:
- Multiple `<script>` tags without `defer`/`async` → LCP + INP risk
- Images without `width`/`height` → CLS risk
- Booking/chat widget JS loaded synchronously → INP risk
- No `<link rel="preload">` for hero image → LCP risk
- Web font loaded via `@import` in CSS → LCP risk

---

## 7. Content Strategy & Freshness {#content}

### Topic Cluster Model
```
Pillar Page — "Board Game Café Nottingham" (broad; covers everything)
  ├─ Cluster: "Board Game Nights Nottingham" (recurring events)
  ├─ Cluster: "Wargaming Nottingham" (specific activity)
  ├─ Cluster: "RPG Gaming Nottingham" (specific activity)
  ├─ Cluster: "CCG Events Nottingham" (specific activity)
  └─ Cluster: "Nottingham Tabletop Community" (audience/community angle)
```
Pillar links to all clusters; clusters link back to pillar + cross-link to each other.
This structure signals topical authority far faster than isolated individual pages.

### Content Freshness Signals (Often Ignored)
Google measures freshness from multiple signals — not just the "last updated" date:
- New backlinks pointing to the page
- Changes to body text (not just the date stamp)
- User engagement signals (dwell time, return visits)
- Page is crawled more frequently = more authority

**Freshness tactics:**
- Add new examples, data, or sections on a schedule (quarterly minimum for key pages)
- Add "What's new in [year]" sections to evergreen guides
- Refresh seasonal content 6–8 weeks before the relevant season
- Update meta title to include the current year where relevant: "Best Board Games 2026"

### Content Refresh vs. New Page
**Refresh when:** page already ranks (any position), URL has backlinks, content is mostly right but stale
**New page when:** different intent from existing content, entirely new topic, existing page is too off-topic to salvage

### Content-Length Strategy
Don't pad. Don't under-serve. Match to intent:
| Intent | Ideal Length | Why |
|---|---|---|
| Transactional (booking/product) | 300–700 words | User has decided; they need to act |
| Local landing page | 500–1,200 words | Enough to rank; not enough to overwhelm |
| Informational blog/guide | 1,200–3,000 words | Depth expected; answer follow-ups |
| Comprehensive pillar | 3,000–6,000 words | Topical authority signal |
| FAQ page | 1,000–2,500 words | Many questions = semantic coverage |

---

## 8. Featured Snippets & Rich Results {#snippets}

Featured snippets appear above position 1. Rich results add visual elements.
Both are captured through structural formatting and schema — not just keyword stuffing.

### Paragraph Snippet (definition/answer)
Format: H2 or H3 as a question → answer in 40–60 words directly below
```html
<h2>What is a board game café?</h2>
<p>A board game café is a venue where visitors pay a session fee to play from a curated library
of board games, typically alongside food and drinks service. Sessions usually last 2–4 hours
and cater to groups of all experience levels.</p>
```

### List Snippet (steps or ranked items)
Format: H2 → `<ol>` or `<ul>` with items Google can extract
```html
<h2>How to book a table at Games Haven</h2>
<ol>
  <li>Visit our booking page at gameshaven.co.uk/book</li>
  <li>Select your date, time, and number of players</li>
  <li>Choose your session type (casual play, tournament, RPG)</li>
  <li>Confirm and receive your booking confirmation email</li>
</ol>
```

### Table Snippet
Format: `<table>` with a clear `<caption>` or H2 above it
Best for: pricing comparisons, opening hours, stat comparisons

### FAQ Rich Result
Schema: `FAQPage` type with `Question` + `Answer` pairs
Rule: questions must match real user queries; answers must be concise (Google truncates at ~300 chars)
```json
{
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How much does it cost to play at Games Haven?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Entry is £7.50 per person, or £12.50 for couples on any day. Membership is available for regular visitors with additional perks."
      }
    }
  ]
}
```

### "People Also Ask" Targeting
PAA questions are pure featured snippet opportunities. Strategy:
1. Search your target keyword in Google
2. Note all PAA questions
3. Add each as an H3 in your content with a direct 40–60 word answer below
4. Add FAQPage schema for the most important 3–5 Q&A pairs

---

## 9. Link Building — 2026 {#links}

**Principle**: editorial links from topically relevant, high-quality sources > volume.
A single link from a relevant authority beats 100 links from low-quality directories.

### Highest-Value Tactics
| Tactic | How | Effort |
|---|---|---|
| Digital PR / data journalism | Create original research/data; pitch to niche press | High |
| HARO / Connectively / Qwoted | Respond as expert to journalist queries | Med |
| Guest posts | Only genuinely relevant, editorial-quality sites | Med |
| Broken link building | Find broken links on authority sites; offer your page | Med |
| Partnerships & suppliers | Ask existing business relationships for links | Low |
| Local press and directories | Nottingham Post, local blogs, community sites (for local businesses) | Low |
| Resource page links | "Link to us" outreach to relevant resource lists | Low |

### What to Avoid
- Paid links without `rel="nofollow"` or `rel="sponsored"` (Google penalty risk)
- Bulk directory submissions to low-quality directories
- Reciprocal link schemes ("I'll link to you if you link to me")
- Exact-match anchor text in bulk (Penguin flag)
- Links from off-topic niches (dilutes topical relevance signal)

### Anchor Text Distribution (Natural Profile)
- ~40% branded ("Games Haven", "gameshaven.co.uk")
- ~30% generic ("click here", "read more", "this article")
- ~20% partial match ("board game café in Nottingham")
- ~10% exact match ("board game café nottingham")
Unnatural = all exact-match anchors; triggers Penguin.

---

## 10. AI Search Optimisation (GEO/AIO) {#ai}

With Google AI Overviews, ChatGPT, Perplexity, and Gemini surfacing content directly in answers:

### How AI Systems Choose What to Cite
1. **Entity recognition** — clearly named entity (business, person, place) with consistent information
2. **E-E-A-T signals** — most authoritative source wins; domain trust + content depth
3. **Structural clarity** — clean HTML with questions/answers as explicit pairs (H2 → paragraph)
4. **Transcript availability** — for video content; clean transcripts = parseable answers
5. **NLP-friendly prose** — plain language that directly answers the question without jargon preamble

### Practical Optimisation Steps
- Structure pages as Q&A: "What is X?" H2 → direct answer in first sentence
- Ensure NAP (Name/Address/Phone) is identical and crawlable sitewide (entity consistency)
- Maintain accurate information on Wikipedia, Wikidata, Crunchbase, GBP (feeds LLM knowledge graphs)
- Write content from a clear authorial perspective — AI systems prefer attributed voices over anonymous text
- Use `speakable` schema for content designed to be read aloud or surfaced in voice results

### AI Overview Appearance Indicators
Pages that tend to appear in AI Overviews:
- First-result or position 1–5 for the query
- Strong FAQ schema
- Direct question–answer structure
- Long-form, comprehensive, expert content
- Cited by other authoritative pages in the niche

---

## 11. Local SEO — Deep Dive {#local}

### The Local Ranking Triangle
Google's local ranking uses three factors:
1. **Relevance** — how well your listing matches the query (categories, description, services)
2. **Distance** — physical proximity to the searcher's location
3. **Prominence** — how well-known and trusted the business is (reviews, links, mentions)

You can only partially control distance. Relevance and prominence are fully in your control.

### Google Business Profile — Full Checklist
- [ ] Claimed and verified (phone/postcard verification)
- [ ] Primary category: most specific accurate match ("Board Game Store" not just "Entertainment")
- [ ] Secondary categories: all relevant ones added
- [ ] Business name: exactly as registered; no keyword stuffing in name field
- [ ] Description: 750 chars, keyword-rich, benefit-led, unique to GBP
- [ ] Address: exactly matching website footer and all other citations
- [ ] Phone: local number preferred; matches website and citations
- [ ] Website URL: points to most relevant page (homepage or location page)
- [ ] Hours: complete, accurate, holiday hours updated in advance
- [ ] Attributes: all applicable (wheelchair accessible, LGBTQ+ friendly, etc.)
- [ ] Photos: 10+ real photos (exterior, interior, products/services, team); updated regularly
- [ ] Google Posts: at least 1 per week (events, offers, updates)
- [ ] Q&A: pre-populate with 5–10 frequently asked questions
- [ ] Products/Services: full list with descriptions and prices

### Review Strategy
- Ask every satisfied customer promptly (email follow-up or in-person QR code)
- Respond to every review — positive and negative — within 48 hours
- Never incentivise reviews (violates Google's terms; can result in suspension)
- Respond to negatives professionally: acknowledge, apologise, offer resolution offline
- Target: 4.3+ average; 50+ reviews minimum for meaningful local pack presence

### Citation Building
Priority citations for UK local business:
1. Google Business Profile
2. Bing Places
3. Apple Maps (via Apple Maps Connect)
4. Yelp UK
5. Yell.com
6. Thomson Local
7. Facebook Business page
8. Industry-specific directories (e.g. TableTop.events, BGGG café listings)

---

## 12. Keyword Cannibalism Diagnosis {#cannibalism}

Keyword cannibalism = two or more pages competing for the same intent/keyword.
Google must choose which to rank; both typically underperform versus one strong page.

### How to Identify
1. Search `site:yourdomain.com keyword` — multiple results for same intent = cannibalism
2. Check GSC → Performance → Queries → filter by keyword → see which URLs appear
3. If 2+ URLs rank for same keyword and alternate position week-to-week = confirmed cannibalism

### How to Fix
| Scenario | Fix |
|---|---|
| One page is clearly stronger | 301 redirect weaker page to the stronger one |
| Both have unique content | Consolidate into one comprehensive page; 301 the other |
| Different intent on same keyword | Differentiate clearly: optimise each for a distinct intent |
| Near-duplicate pages | Merge content; canonical the weaker to the stronger |

### Games Haven Example
Pages `/rpg-gaming-nottingham/`, `/games-haven-rpg-gaming/nottingham-rpg-gaming/`, and `/games-haven-rpg-gaming/` all target "RPG gaming Nottingham". Fix: consolidate into one definitive RPG page at `/rpg-nottingham/` or `/rpg-gaming-nottingham/`; redirect others.

---

## 13. Penalty & Traffic Drop Recovery {#recovery}

### Step 1 — Diagnose the Drop Type
| Pattern | Likely Cause |
|---|---|
| Sudden drop on Google algorithm update date | Content quality / E-E-A-T issue (check HCU, Helpful Content Update) |
| Gradual decline over weeks | Content freshness; competitor improvement; intent drift |
| Drop on specific pages only | On-page issue, thin content, or cannibalism |
| Drop sitewide | Technical issue (noindex, crawl block, manual penalty, hosting downtime) |
| Drop then recovery | Probably a test; Google rolled back or reassessed |

### Step 2 — Check GSC Immediately
- Coverage tab: any new "Excluded" or "Error" pages?
- Manual Actions tab: any penalties?
- Security Issues tab: any malware flags?
- Core Web Vitals tab: any sudden deterioration?

### Step 3 — Recovery Actions by Cause
| Cause | Actions |
|---|---|
| Helpful Content / HCU | Add E-E-A-T signals; add author credentials; add first-person experience; remove AI-slop sections |
| Thin content | Expand with real data, examples, expert perspective; merge thin pages |
| Technical (noindex/robots) | Fix immediately; submit URL to GSC for recrawl |
| Competitor improved | Study top 3 results; identify what you're missing; update page |
| Manual penalty | Fix the issue; submit reconsideration request via GSC |

---

## 14. Schema Reference — Full Templates {#schema}

### Organization (brand homepage)
```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Games Haven",
  "url": "https://gameshaven.co.uk",
  "logo": "https://gameshaven.co.uk/logo.png",
  "sameAs": [
    "https://www.facebook.com/gameshaven",
    "https://www.instagram.com/gameshaven",
    "https://discord.gg/gameshaven"
  ]
}
```

### Article / BlogPosting
```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Title matching H1",
  "author": { "@type": "Person", "name": "Author Name", "url": "https://example.com/author/" },
  "datePublished": "2026-01-15",
  "dateModified": "2026-04-01",
  "publisher": { "@type": "Organization", "name": "Games Haven" },
  "image": "https://example.com/article-image.webp",
  "description": "Meta description text"
}
```

### FAQPage
```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Question text matching user query?",
      "acceptedAnswer": { "@type": "Answer", "text": "Direct answer. Under 300 chars for rich result." }
    }
  ]
}
```

### VideoObject (for pages embedding YouTube videos)
```json
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "Exact YouTube title",
  "description": "Video description",
  "thumbnailUrl": "https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg",
  "uploadDate": "2026-01-15",
  "duration": "PT8M30S",
  "embedUrl": "https://www.youtube.com/embed/VIDEO_ID"
}
```

### HowTo
```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to [Task]",
  "step": [
    { "@type": "HowToStep", "name": "Step 1 name", "text": "Step 1 full instruction." },
    { "@type": "HowToStep", "name": "Step 2 name", "text": "Step 2 full instruction." }
  ]
}
```

### BreadcrumbList
```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://example.com/" },
    { "@type": "ListItem", "position": 2, "name": "Blog", "item": "https://example.com/blog/" },
    { "@type": "ListItem", "position": 3, "name": "Article Title", "item": "https://example.com/blog/article-slug/" }
  ]
}
```

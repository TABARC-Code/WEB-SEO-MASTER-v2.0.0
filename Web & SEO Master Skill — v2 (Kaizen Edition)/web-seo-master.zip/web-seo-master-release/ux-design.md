# UX Design, Visual Design & User Retention — Deep Reference v2 (2026)

## Table of Contents
1. [Visual Hierarchy System](#hierarchy)
2. [Hero Section Formula](#hero)
3. [Typography System](#typography)
4. [Colour System & Dark Mode](#colour)
5. [Layout Patterns & Grid](#layout)
6. [Navigation Design](#navigation)
7. [Mobile-First Design](#mobile)
8. [Accessibility (WCAG 2.2 AA)](#accessibility)
9. [Micro-interactions & Animation](#animation)
10. [User Retention Mechanics](#retention)
11. [Error & Empty State Design](#errors)
12. [Design Anti-Patterns to Eliminate](#antipatterns)
13. [Design for SEO (UX-SEO Intersection)](#uxseo)
14. [2026 Design Trends (Apply Selectively)](#trends)
15. [Testing & Validation](#testing)

---

## 1. Visual Hierarchy System {#hierarchy}

Visual hierarchy = the system that tells users what to look at, in what order.
First impressions form in under 50ms — visual hierarchy must work before any text is read.

### The Six Levers (priority order)

**1. Size** — largest element = most important
- H1 must be noticeably larger than everything else (not just 2px bigger)
- CTAs must be larger than surrounding body text
- Rule: if two elements compete for attention, make the winner noticeably bigger

**2. Contrast** — high contrast = eye is drawn there
- Use contrast (colour, value, weight) for: CTAs, key stats, headlines, alerts
- Low contrast = visual support, not focal point
- WCAG minimum for interactive UI: 3:1 contrast ratio

**3. Position** — top of page and top-left gets eye first
- Above the fold: only the most important content (hero, CTA, headline)
- Top-left (Western reading cultures): first to receive attention
- Center alignment: draws equal attention; use for hero headlines
- Footer: lowest priority zone

**4. Spacing** — whitespace is not waste; it's signal
- Generous padding between sections = breathing room = lower cognitive load
- Tight spacing groups related items (Gestalt proximity principle)
- Premium brands use more whitespace than utility brands

**5. Typography Weight** — creates reading hierarchy without colour
- Bold → Regular → Light = natural hierarchy
- Maximum 3 weight variants per page
- Bold reserved for: H1, H2, CTA labels, key stats only

**6. Colour** — scarcity creates value
- Brand accent = highest attention; use it sparingly
- One accent colour for primary CTA only; nowhere else
- When everything is accented, nothing stands out

### Page Anatomy — Hierarchy in Practice
```
HERO [Maximum everything — size + contrast + position + colour]
  H1: largest text on page; keyword + benefit
  Sub-headline: 60–70% H1 size; removes biggest objection
  Primary CTA: accent colour; nothing else this colour
  Social proof strip: star rating + count; or logo row

VALUE SECTION [Medium hierarchy — draws in readers who need more]
  H2: much smaller than H1 but clear section leadership
  Benefit cards: equal hierarchy within the grid

SOCIAL PROOF [Supporting — builds conviction, not competing]
  Testimonials: real names, real photos, real outcomes

FINAL CTA [Repeated — different treatment, same goal]
  Outline variant or re-stated primary button
```

---

## 2. Hero Section Formula {#hero}

The hero decides whether a visitor stays or leaves. Most heroes fail.

### What Makes a Hero Work
The hero must communicate, in under 5 seconds without scrolling:
1. **What this is** (product/service/place)
2. **Who it's for** (the visitor should recognise themselves)
3. **Why it matters** (the primary benefit)
4. **What to do next** (one action, clearly signposted)

### Hero Construction Template
```
H1: [Primary keyword] — [Clearest benefit in ≤10 words]
    Bad: "Games Haven UK"
    Good: "Nottingham's Tabletop Gaming Hub — Drop In and Play"

Sub-headline: [Removes the biggest single objection or adds context]
    Bad: "We have lots of games and events for everyone"
    Good: "300+ board games, weekly RPG nights, and zero gatekeeping.
           £7.50 gets you a full day of play."

Hero visual: [Reinforces the headline; shows real people using the product]
    Bad: stock photos
    Good: real photos of customers playing; venue interior; real atmosphere

Primary CTA: [Benefit verb + outcome]
    Bad: "Learn More" / "Click Here" / "Submit"
    Good: "Book My Table" / "Reserve Your Spot" / "See What's On Tonight"

Micro-copy: [Under the CTA; removes anxiety]
    "Takes 60 seconds to book"
    "No account needed"
    "Free cancellation up to 24 hours before"

Social proof strip: [Immediately below CTA]
    "★★★★★ 4.8 from 247 Google Reviews"
    or "Visited by 15,000+ players in 2025"
```

### Hero Anti-Patterns (Real Failures)
| Anti-Pattern | Problem | Fix |
|---|---|---|
| Brand name as H1 | Tells visitors nothing new | Replace with keyword + benefit |
| Two equal-weight CTAs above fold | Splits attention; lowers both conversion rates | One primary (filled) + one secondary (outline, smaller) |
| Generic stock photo hero | No authenticity signal; looks like every other site | Real photos of real customers in real venue |
| Pricing buried below fold | Decision-critical information hidden | Surface pricing in hero or as a stat near the CTA |
| No social proof near CTA | Maximum anxiety at decision moment | Add review count or guarantee within 100px of CTA |

---

## 3. Typography System {#typography}

### Modular Scale (Major Third: 1.250)
| Element | Responsive Range | Weight | Line Height | Notes |
|---|---|---|---|---|
| Display/H1 | clamp(40px, 6vw, 96px) | 700–900 | 1.1–1.2 | One per page; keyword in first 3 words |
| H2 | clamp(28px, 4vw, 56px) | 600–700 | 1.2–1.3 | Scannable section leaders |
| H3 | clamp(22px, 3vw, 36px) | 500–600 | 1.3–1.4 | Question-format for snippets |
| H4 | clamp(18px, 2.5vw, 28px) | 500 | 1.4 | Rarely needed |
| Body | clamp(16px, 1.5vw, 18px) | 400 | 1.5–1.7 | Max 65 chars per line |
| CTA | 16–20px | 600–700 | 1 | Action verb + benefit |
| Caption/label | 12–14px | 400 | 1.4 | Never below 12px |
| Navigation | 14–16px | 400–500 | 1 | Descriptive not clever |

```css
/* Fluid typography — 2026 standard */
h1 { font-size: clamp(2.5rem, 6vw, 6rem); line-height: 1.15; letter-spacing: -0.02em; }
h2 { font-size: clamp(1.75rem, 4vw, 3.5rem); line-height: 1.25; }
body { font-size: clamp(1rem, 1.5vw, 1.125rem); line-height: 1.65; }
p { max-width: 65ch; } /* Prevents over-long lines */
```

### Font Pairing Rules
- Maximum 2 typefaces: one display (headlines) + one body
- Variable fonts preferred: one file covers all weights (performance win)
- Classic pairings: Serif headline + Sans body; Geometric sans + Humanist sans
- Avoid: two decorative fonts; system fonts for brand-critical text

### Readability Rules
- Line length: 45–75 characters (use `max-width: 65ch`)
- Line height body: 1.5–1.7
- Paragraph spacing: 1.5× line height
- Avoid: justified alignment (creates "rivers"); all-caps body text; font sizes below 14px in body

---

## 4. Colour System & Dark Mode {#colour}

### Colour Architecture
```
Brand Primary (1)    — primary CTA only; nowhere else
Brand Secondary (1)  — accents, hover states, secondary elements  
Neutral Scale (5–7)  — backgrounds, dividers, body text
Semantic colours     — success (green), warning (amber), error (red), info (blue)
```

### WCAG 2.2 AA Contrast Requirements
| Text Type | Minimum Contrast |
|---|---|
| Body text (< 18pt / 14pt bold) | 4.5:1 against background |
| Large text (≥ 18pt / ≥ 14pt bold) | 3:1 against background |
| UI components (buttons, icons, inputs) | 3:1 against adjacent colour |
| Placeholder text in inputs | 4.5:1 (same as body) |

Tools: WebAIM Contrast Checker, browser DevTools Accessibility panel, Stark plugin

### Accessible Colour Building System
1. Choose your brand primary
2. Generate a contrast-safe text version (usually 700–900 on a scale)
3. Generate a contrast-safe background version (usually 50–100 on a scale)
4. Check both against white and dark backgrounds
5. Repeat for semantic colours

### Dark Mode Implementation
```css
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f4;
  --text-primary: #1a1a1a;
  --text-secondary: #5a5a5a;
  --accent: #3B6D11;       /* brand green */
  --accent-light: #EAF3DE; /* for backgrounds */
}

@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: #1a1a1a;
    --bg-secondary: #252525;
    --text-primary: #f0ede8;
    --text-secondary: #a8a49f;
    --accent: #97C459;       /* lighter for dark bg */
    --accent-light: #27500A; /* darker for dark bg */
  }
}
```
Rule: never hardcode `#333` or `#fff` — always use CSS variables. Pure black (#000) causes halation on OLED; use `#0f0f0f` or `#1a1a1a`.

### Colour Psychology (Apply Purposefully)
| Colour | Associations | Best For |
|---|---|---|
| Blue | Trust, calm, professionalism | SaaS, finance, healthcare, B2B |
| Green | Growth, safety, go-signal | CTA buttons, success states, eco brands |
| Orange | Energy, urgency, warmth | CTAs in entertainment/food, flash sales |
| Red | Urgency, danger, passion | Error states, countdown timers, strong CTAs |
| Purple | Creativity, luxury, wisdom | Tech startups, creative agencies |
| Black | Premium, authority, confidence | Luxury brands, fashion |

---

## 5. Layout Patterns & Grid {#layout}

### 12-Column Responsive Grid
```css
.container {
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: clamp(16px, 2vw, 24px);
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 clamp(16px, 4vw, 48px);
}
```

### Spacing System
```css
--space-2:  clamp(4px, 0.5vw, 8px);
--space-4:  clamp(8px, 1vw, 12px);
--space-8:  clamp(16px, 2vw, 24px);
--space-16: clamp(24px, 3vw, 40px);
--space-32: clamp(48px, 6vw, 80px);
--space-64: clamp(80px, 10vw, 128px);

section { padding: var(--space-64) 0; }
.card-grid { gap: var(--space-16); }
```

### Section Patterns

**Feature Grid (3-col or 4-col)**
```
H2 section title (centred or left)
[Icon/visual] [Icon/visual] [Icon/visual]
  Title         Title         Title
  2–3 sentence  2–3 sentence  2–3 sentence
  description   description   description
```

**Testimonial Section**
```
H2: "What Our Players Say"
[Photo + Name + Role] [Photo + Name + Role] [Photo + Name + Role]
"Specific outcome      "Specific outcome      "Specific outcome
quote. Named person.   quote. Named person.   quote. Named person.
Real result stated."   Real result stated."   Real result stated."
```

**Stats Strip**
```
[Large Number] [Large Number] [Large Number] [Large Number]
 Label          Label          Label          Label
```
Numbers: real, specific, credibility-building.
"300+ games in our library" > "lots of games"
"4.8★ from 247 reviews" > "highly rated"

**CTA Band**
```
[Full-width colour background]
H2: [Benefit-led headline — what they get]
Supporting line: [Remove last objection]
[Primary CTA button]
[Micro-copy below button]
```

---

## 6. Navigation Design {#navigation}

### Navigation Types
| Type | Use Case | Rule |
|---|---|---|
| Top horizontal | 3–7 links; marketing/brochure sites | Default expectation; don't break it |
| Hamburger | Mobile; or >7 links | Must show accessible open/close state |
| Sticky header | Long-scroll pages | Keep lightweight; don't obstruct content |
| Mega menu | Large catalogue sites | Only justified for >10 major sections |
| Bottom nav | Mobile apps | Thumb zone; 4–5 items max |

### Navigation Best Practices
- 5–7 items maximum (cognitive load limit)
- Labels: descriptive over clever ("Events" not "What's On"; "Pricing" not "Plans")
- Active state: always show which page the user is on (colour + underline or weight)
- Logo always links home — never broken
- Primary CTA as a button in top-right nav (highest conversion position)
- Search: include if site has > 50 pages of content

### Navigation Label Audit
| Bad Label | Problem | Better Label |
|---|---|---|
| "GH Events" | Requires brand knowledge | "Gaming Events" |
| "lgtbq+ Nights" | Wrong capitalisation | "LGBTQ+ Nights" |
| "Tabletop Talk" | Vague | "Gaming Blog" |
| "Café" | Ambiguous (café? food?) | "Café Menu & Drinks" |

### Breadcrumbs
```html
<nav aria-label="Breadcrumb">
  <ol itemscope itemtype="https://schema.org/BreadcrumbList">
    <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
      <a itemprop="item" href="/"><span itemprop="name">Home</span></a>
      <meta itemprop="position" content="1" />
    </li>
    <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
      <a itemprop="item" href="/blog/"><span itemprop="name">Blog</span></a>
      <meta itemprop="position" content="2" />
    </li>
    <li aria-current="page">Current Page Title</li>
  </ol>
</nav>
```

---

## 7. Mobile-First Design {#mobile}

### The Principle
Design for 375px viewport first. Expand to larger screens with `min-width` media queries.
Never design desktop-first then try to "make it work" on mobile — the result always suffers.

### Thumb Zone Map
```
iPhone viewport (375×812px)

[TOP ZONE — hard to reach one-handed]
  Logo, secondary navigation, back buttons

[NATURAL ZONE — comfortable with thumb]
  Content cards, images, body text

[PRIME ZONE — easy thumb reach]
  Primary CTA, tab bar, floating action buttons
```
Place all critical conversion actions in the prime/natural zones.

### Mobile-First Checklist
- [ ] Designed at 375px first; layout tested at 320px (minimum support)
- [ ] All tap targets ≥ 44×44px (Apple) / 48×48px (Material) with 8px minimum gap
- [ ] Body font ≥ 16px (smaller triggers iOS zoom on input focus)
- [ ] No horizontal scroll at any viewport
- [ ] Hero CTA visible without scrolling on 375px viewport
- [ ] Form inputs trigger correct keyboard (email, tel, number, text)
- [ ] Navigation accessible without hover states
- [ ] Images use `srcset` for responsive sizing

### Responsive Images
```html
<img
  src="hero-800.webp"
  srcset="hero-400.webp 400w, hero-800.webp 800w, hero-1200.webp 1200w"
  sizes="(max-width: 600px) 100vw, (max-width: 1200px) 80vw, 1200px"
  width="1200" height="630"
  alt="Descriptive alt text with keyword"
  fetchpriority="high"
  loading="eager"
>
```

---

## 8. Accessibility (WCAG 2.2 AA) {#accessibility}

### Why It's Not Optional
- Legal requirement: UK Equality Act; US ADA; EU European Accessibility Act (EAA) enforcement from 2025
- SEO signal: accessible HTML is semantically rich HTML; Google parses it better
- User base: 15%+ of UK population has a disability; accessible sites reach them all
- Conversion: keyboard and screen reader users convert too — broken accessibility = lost revenue

### WCAG 2.2 AA Checklist

**Perceivable**
- [ ] All meaningful images have descriptive alt text; decorative images have `alt=""`
- [ ] Colour is not the only means of conveying meaning (always add icon or label)
- [ ] Text contrast ≥ 4.5:1 (body), ≥ 3:1 (large text, UI)
- [ ] Videos have accurate captions; audio has text transcripts
- [ ] Content reflows at 400% zoom without horizontal scroll

**Operable**
- [ ] All interactions keyboard-accessible (Tab, Enter, Space, Arrow keys)
- [ ] Visible focus ring on every focusable element (never `outline: none`)
- [ ] No keyboard traps — user can Tab into and out of every component
- [ ] Skip link: "Skip to main content" as first focusable element
- [ ] No content flashing > 3 Hz (seizure risk)
- [ ] Page title `<title>` is descriptive and unique

**Understandable**
- [ ] `<html lang="en">` (or correct language) on every page
- [ ] `<label for="...">` associated with every form input
- [ ] Error messages identify the problem and suggest a fix
- [ ] Consistent navigation across all pages

**Robust**
- [ ] Valid semantic HTML (heading hierarchy; landmark elements)
- [ ] ARIA only used to supplement, not replace, semantic HTML
- [ ] Tested with keyboard only (no mouse)
- [ ] Tested with VoiceOver (Mac/iOS) or NVDA (Windows)

### Semantic HTML Reference
```html
<header role="banner">   — site/page header
<nav aria-label="Main">  — navigation (label when multiple navs)
<main id="content">      — primary page content; one per page
<article>                — self-contained content (blog post, card)
<section>                — thematic group; always needs a heading
<aside>                  — supplementary content (sidebar, related)
<footer role="contentinfo"> — page footer
<h1>–<h6>               — hierarchy; never skip levels
<button>                 — interactive clicks (not <div onclick>)
<a href="...">           — navigation/links (not <span onclick>)
<label>                  — form field labels; always associated
<fieldset> + <legend>    — form groupings
```

---

## 9. Micro-interactions & Animation {#animation}

### When Animation Helps vs. Hurts
| Helps | Hurts |
|---|---|
| Confirms action (button press → state change) | Delays content appearance |
| Shows loading state (skeleton → content) | Distracts from core content |
| Guides focus to new information | Triggers vestibular issues |
| Smooth state transitions | Autoplay background video (LCP + accessibility) |

### Animation Rules
- Duration: micro-interactions 100–200ms; page transitions 250–400ms; avoid > 500ms for UI
- Easing: `ease-out` for entering; `ease-in` for exiting; `ease-in-out` for transforms
- Only animate `transform` and `opacity` (GPU-composited; no layout reflow)
- Never animate: `width`, `height`, `top`, `left`, `margin`, `padding`

```css
/* Always respect reduced motion */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    scroll-behavior: auto !important;
  }
}

/* Scroll-triggered fade-up — CSS only (2026 baseline) */
@keyframes fade-up {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
.animate-in {
  animation: fade-up 0.4s ease-out both;
  animation-timeline: view();
  animation-range: entry 0% cover 25%;
}
```

### Button Interaction Pattern
```css
.btn-primary {
  background: var(--accent);
  color: var(--text-on-accent);
  padding: 14px 32px;
  border-radius: 6px;
  font-weight: 600;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  cursor: pointer;
}
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 16px rgba(0,0,0,0.15); }
.btn-primary:active { transform: translateY(0); box-shadow: none; }
.btn-primary:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }
```

---

## 10. User Retention Mechanics {#retention}

### The Retention Equation
```
Retention = Value Delivered − Friction Encountered
```
Every design decision either increases value or increases friction. Audit both relentlessly.

### The 5-Stage Retention Framework
1. **Onboarding**: First visit makes success inevitable within 2 minutes
2. **Habit loop**: Navigation and content discovery form a returning behaviour
3. **Re-engagement**: Email, push, Community posts bring users back
4. **Personalisation**: Browsing history and recommendations make it feel bespoke
5. **Progress signals**: Membership perks, streaks, badges reinforce continuation

### Onboarding Principles
- Reduce time-to-value to under 60 seconds
- Don't require account creation before experiencing value
- Empty state design: tell the user exactly what to do when nothing has happened yet
- Progressive disclosure: reveal advanced features only after basics are mastered

### Internal Linking for Retention
- 3–8 contextual links per page (in body copy — highest click rate)
- "Related articles" widget at every blog post end
- Tag/category pages for browsing by topic
- Table of contents on long pages (reduces abandonment from overwhelm)
- "Next in series" navigation for sequential content

### Email Capture Best Practices
- Value exchange framing: "Get the free [specific thing]" not "Subscribe to our newsletter"
- Trigger timing: exit-intent OR post-60%-scroll OR post-read (not on page load)
- Fields: first name + email only (every extra field = fewer signups)
- Thank-you page: deliver the promised value immediately; offer a next step

---

## 11. Error & Empty State Design {#errors}

### Form Error States
- Show error inline, adjacent to the field that caused it
- Don't clear the user's input on error (they'll have to retype)
- Specific error message: "Please enter a valid UK mobile number (e.g. 07700 900123)" not "Error"
- Use red + icon (never colour alone) for accessibility

```html
<label for="phone">Phone number</label>
<input type="tel" id="phone" aria-describedby="phone-error" aria-invalid="true">
<p id="phone-error" role="alert" style="color: red;">
  Please enter a valid UK phone number, e.g. 07700 900123
</p>
```

### Empty States (Equally Important)
When a page section has no content (search returns nothing, cart is empty):
- Don't show a blank page or generic "Nothing here"
- Show: what should be here + why it's empty + what to do next

```
"No events found for your search."
Try: [Browse all events] or [Clear filters]
```

### 404 Page Design
A 404 should never be a dead end:
- Acknowledge the problem briefly ("That page has moved or doesn't exist")
- Offer navigation paths (Homepage, popular sections, search)
- Match brand design — a generic 404 is a trust break

---

## 12. Design Anti-Patterns to Eliminate {#antipatterns}

These are real patterns that hurt UX, SEO, and conversion — eliminate them on sight.

| Anti-Pattern | What It Looks Like | Why It Hurts | Fix |
|---|---|---|---|
| Dual primary CTAs | Two equal-weight buttons above fold | Splits attention; both convert worse | One filled + one outline; clearly subordinate |
| Brand name as H1 | H1 says "Company Name" not a benefit | Wasted keyword opportunity; unclear value prop | Replace with keyword + benefit |
| Vague hero copy | "We're passionate about games" | Says nothing; doesn't help user decide | Specific: who/what/why/where |
| Generic stock photos | Smiling people with perfect teeth; no context | Zero authenticity; low trust | Real photos of real venue/product/people |
| "Submit" buttons | Form button says "Submit" | Generic; high anxiety; low conversion | Replace with outcome: "Book My Table" |
| Unincentivised newsletter | "Subscribe to our newsletter" | Zero value exchange; <0.5% conversion | "Get [specific thing]" |
| Pop-up on page load | Overlay appears within 2 seconds | Interrupts before value delivered; Google penalises | Exit-intent or post-60%-scroll |
| Hidden pricing | Price only on a separate page or not at all | Creates anxiety; loses transactional visitors | Surface price near CTA |
| "Learn More" as only CTA | Single CTA goes to more info, not action | Delays conversion; low intent visitors only | Add primary action CTA alongside |
| Competing copyright dates | Footer says "© 2019" and "© 2026" | Trust break; signals neglect; staleness signal | Fix to current year; automate |
| Accordion navigation | Menu items hidden until hover/click | Invisible to crawlers; frustrating on mobile | Flat navigation with visible labels |
| Auto-play media | Video or audio starts automatically | Accessibility failure; user distrust; LCP damage | User-initiated only; always |
| Tiny tap targets | Links/buttons < 40px on mobile | Rage taps; accessibility failure | ≥ 44px all touch targets |

---

## 13. Design for SEO (UX-SEO Intersection) {#uxseo}

### How Google Measures UX Satisfaction
- **Dwell time**: did the user stay and engage after clicking from search?
- **Pogo-sticking**: did they immediately return to SERPs? (strong negative signal)
- **Scroll depth**: did they reach the content they searched for?
- **Pages per session**: did they go deeper?

### Design Decisions That Directly Affect SEO Signals
- **Above-fold match**: hero must immediately confirm the user is in the right place
- **LCP performance**: content appears fast = user stays = signal improves
- **CLS = zero**: layout instability destroys trust and triggers bounces
- **Readable typography**: users who can read stay longer; dwell time improves
- **Clear internal links**: contextual links keep users in session; session length improves

### Design Choices That Actively Harm Rankings
- **Intrusive interstitials on load** (pop-ups within 2 seconds) — Google penalises since 2017
- **Text in images** — not crawlable; use CSS text overlay instead
- **JavaScript-only navigation** — some crawlers can't execute JS; use server-side rendered nav
- **Infinite scroll without pagination** — crawlers can't follow; add URL-based pagination
- **Content below a huge hero with no text** — crawler sees hero first; text content is deprioritised

---

## 14. 2026 Design Trends {#trends}

Apply only when they serve the user and the brand. Trends are tools, not requirements.

| Trend | When to Use | When to Avoid |
|---|---|---|
| Bold oversized typography | Brand/marketing sites; hero statements | Dense content; enterprise; legal/medical |
| Bento grid layout | Feature showcases; portfolios; dashboards | Linear guides; news; tutorials |
| Glassmorphism | Premium navigation; modals; overlays | Low contrast risk; conservative industries |
| Scroll-driven animation | Storytelling; brand narrative sites | Accessibility-sensitive; news; utilities |
| Dark mode | Tech; entertainment; creative tools | Always provide toggle; test contrast rigorously |
| Kinetic/animated typography | Hero statements; brand moments | Body copy (illegible); reduced-motion users |
| AI personalisation | E-commerce; content platforms | Be transparent about data use; GDPR compliance |
| Variable fonts | All sites — performance + design flexibility | No avoidance; load correctly |
| Fluid organic shapes | Consumer; wellness; creative brands | B2B; government; traditional |

---

## 15. Testing & Validation {#testing}

### UX Testing Methods
| Method | What It Reveals | When |
|---|---|---|
| First-click test | Is hierarchy working? Where do users click? | Before launch; redesigns |
| 5-second test | First impression; "what does this site do?" | Hero section validation |
| Heatmaps (Hotjar/Clarity) | Click patterns; scroll depth; rage clicks | Post-launch; continuous |
| Session recordings | Real user behaviour; confusion points | Post-launch; after complaints |
| A/B test | Which version converts better? | When traffic > 1000 visits/test |
| User interviews | Why users behave as they do | When analytics shows *what* but not *why* |
| Lighthouse | Technical performance baseline | Every release; CI/CD |
| Screen reader | Accessibility | Before launch; with new interactive components |

### Pre-Launch Checklist
- [ ] Tested in: Chrome, Firefox, Safari, Edge
- [ ] Tested on: iOS Safari (real device), Android Chrome (real device), desktop
- [ ] Viewport tests: 320px, 375px, 768px, 1280px, 1440px
- [ ] Lighthouse: Performance ≥90, Accessibility ≥90, Best Practices ≥90, SEO ≥90
- [ ] Keyboard only: all interactive elements reachable and operable
- [ ] Screen reader: headings make sense; images alt-texted; forms labeled
- [ ] Forms: all submit correctly; all error states display correctly
- [ ] All links: working; no 404s
- [ ] LCP < 2.5s on 4G mobile (use WebPageTest.org)
- [ ] CLS = 0 (no layout shift after images/fonts load)
- [ ] Colour contrast: all body text 4.5:1; all UI 3:1
